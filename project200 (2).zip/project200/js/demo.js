// function to toggle between gif and video maker
(function(window, document) {
    // other variables
    var createGIFButton = document.querySelector('#create-gif');
    var imgHolder = document.querySelector('#imgHolder');
    var arrayChunked = [];
    var imgArray1= [];
    var imgArray2= [];
    var imgArray3= [];
    var imgArray4= [];
    var imgArray5= [];
    var allimage = []
    var imgDatas = []
    var imgArray = [];
	var imagearrayload;
    /* check for images after inputting them  */
    imgHolder.addEventListener("change",()=>{
        var images = imgHolder.files;
        var statusHolder = document.getElementById('status');
       var logo = $("#imgWaterMark").prop('files')[0];
	   var pos = $("#waterpos").val();
		var opacity  = $("#opacity").val();
          	if(images.length % 3 === 0){         
            if($("#imgWaterMark").val() != ""){
                //loop through them and process
									
                countimg = images.length/3;
                for(var i=0; i<images.length; i++) {
					         
                    var file = images[i];
                    if(file.type.match(/image.*/)){
                        imgsrc = URL.createObjectURL(images[i]);
								 if (pos === "center") {
								watermark([imgsrc, logo])
								.image(watermark.image.center(opacity))
								.then(function(img){
								  imgArray.push(img);
									imgDatas.push(img);
								});
							}else if (pos === "upperRight"){
								watermark([imgsrc, logo])
								.image(watermark.image.upperRight(opacity))
								.then(function(img){
								  imgArray.push(img);
									imgDatas.push(img);
								});
						}else if (pos === "upperLeft"){
							watermark([imgsrc, logo])
								.image(watermark.image.upperLeft(opacity))
								.then(function(img){
								  imgArray.push(img);
									imgDatas.push(img);
								});
						 }else if (pos === "lowerRight"){
							 watermark([imgsrc, logo])
								.image(watermark.image.lowerRight(opacity))
								.then(function(img){
								  imgArray.push(img);
									imgDatas.push(img);
								});
					     }else{
							 watermark([imgsrc, logo])
								.image(watermark.image.lowerLeft(opacity))
								.then(function(img){
								  imgArray.push(img);
									imgDatas.push(img);
								});
							 
						 }
                        createGIFButton.addEventListener('click',()=>{statusHolder.innerHTML = "";}); 
                    }else{
                        document.getElementById('status').innerHTML = "This file does not seem to be a image.";
                    }
					
									
                }  
				
                //  JSON.stringify(imgArray)                       
                    
                    imgArray1 = imgArray.slice(0,3);
                    imgArray2 = imgArray.slice(3,6);
                    imgArray3 = imgArray.slice(6,9);
                    imgArray4 = imgArray.slice(9,12);
                    imgArray5 = imgArray.slice(12,15);
                    // console.log(imgArray.0)
                    // chunkArray(imgArray,3);
                    // arrayChunked.length
                    imgArray.forEach(console.log)
                    gifmaker(imgArray1);
                    console.log(imgDatas)
                    gifmaker(imgArray2);
                    // var mynewarray = [imgArray1, imgArray2, imgArray3, imgArray4, imgArray5];    
                    
            }else{
              countimg = images.length/3;
                for(i=0; i<images.length; i++) {
                    var file = images[i];
                    if(file.type.match(/image.*/)){
						 imgsrc = URL.createObjectURL(images[i]);
                         imgArray.push(imgsrc);
						imgDatas.push(imgsrc);
                        createGIFButton.addEventListener('click',()=>{statusHolder.innerHTML = "";}); 
                    }else{
                        document.getElementById('status').innerHTML = "This file does not seem to be a image.";
                    }
                }  
                //  JSON.stringify(imgArray)                       
                    
                    imgArray1 = imgArray.slice(0,3);
                    imgArray2 = imgArray.slice(3,6);
                    imgArray3 = imgArray.slice(6,9);
                    imgArray4 = imgArray.slice(9,12);
                    imgArray5 = imgArray.slice(12,15);
                    // console.log(imgArray.0)
                    // chunkArray(imgArray,3);
                    // arrayChunked.length
                    imgArray.forEach(console.log)
                    gifmaker(imgArray1);
                    console.log(imgDatas)
                    gifmaker(imgArray2);
                    // var mynewarray = [imgArray1, imgArray2, imgArray3, imgArray4, imgArray5];    
                    
            }  
			
			}else{ 
					alert("Please choose images in pair of 3");
					document.querySelector('#imgHolder').value='';
					return false;
					}	
            // gifmaker(imgArray)
    })
	

    function gifmaker(newArray){
		 console.log("gifmaker")
        // all variables for gif maker
          var saveGIFButton = document.querySelector('#save-gif');
        var downloadAttrSupported = ('download' in document.createElement('a'));
        var createGIFButton = document.querySelector('#create-gif');
        var gifSource = document.querySelector('#GIFSource');
        var gifType = document.querySelector('#GIFType');
        var filter = document.querySelector("#filter");
        var interval = document.querySelector("#interval");
        var numFrames = document.querySelector("#numFrames");
        var frameDuration = document.querySelector("#frameDuration");
        var gifHeight = document.querySelector("#gifHeight");
        var gifWidth = document.querySelector("#gifWidth");
        var progressBar = document.querySelector("progress");
        var text = document.querySelector('#gifText');
        var fontWeight = document.querySelector('#fontWeight');
        var fontSize = document.querySelector('#fontSize');
        var fontFamily = document.querySelector('#fontFamily');
        var fontColor = document.querySelector('#fontColor');
        var textAlign = document.querySelector('#textAlign');
        var textBaseline = document.querySelector('#textBaseline');
        var sampleInterval = document.querySelector('#sampleInterval');
        var numWorkers = document.querySelector('#numWorkers');
        var placeholderDiv = document.querySelector('.placeholder-div');
        var placeholderDivDimensions = document.querySelector('.placeholder-div-dimensions');
        var gifshotCode = document.querySelector('.gifshot-code');
        var gifshotCodeTemplate = document.querySelector('.gifshot-code-template');
		alert(newArray[i]);
        var getSelectedOptions = function () {
            console.log("getSelectedOptions")
            return {
                gifWidth: Number(gifWidth.value),
                gifHeight: Number(gifHeight.value),
                images: gifSource.value === 'images' ? newArray[i] : false,
                video: gifSource.value === 'video' ? ['example.mp4', 'example.ogv'] : false,
                filter: filter.value,
                interval: Number(interval.value),
                numFrames: Number(numFrames.value),
                frameDuration: Number(frameDuration.value),
                text: "",
                fontWeight: "",
                fontSize: "",
                fontFamily: "",
                fontColor: "",
                textAlign: "",
                textBaseline: "",
                sampleInterval: Number(sampleInterval.value)
            }
        };

        var passedOptions;
        var updateCodeBlock = function (obj) {
            console.log("updateCodeBlock")
        obj = obj || {};

        var targetElem = obj.targetElem;
        var selectedOptions = getSelectedOptions();
        var options = (function() {
            console.log("options")
            var obj = {};

            _.each(selectedOptions, function(val, key) {
                if (val) {
                    obj[key] = val;
                }
            });

            return obj;
        }());

        };
        var bindEvents = function () {
            console.log("bindEvents")
            createGIFButton.addEventListener('click', function (e) {
                // e.preventDefault();
				
                passedOptions = _.merge(_.clone(getSelectedOptions()), {
                    progressCallback: function (captureProgress) {
                        placeholderDiv.classList.add('hidden');
                        progressBar.classList.remove('hidden');
                        progressBar.value = captureProgress;
                    }
                });

                var method = gifType.value === 'snapshot' ? 'takeSnapShot' : 'createGIF';

                gifshot[method](passedOptions, function(obj) {
                    console.log("gifshot")
                    if (!obj.error) {
                        var image = obj.image;
                        allimage.push(image)
                        if(allimage.length != countimg){
							alert("NO FILE SELECTED");
							return false
                        }else{
                            displayergif()
							
                        }
                        var animatedImage = document.createElement('img');

                        animatedImage.src = image;

                        progressBar.classList.add('hidden');
                        progressBar.value = 0;

                        placeholderDiv.classList.add('hidden');
                        // gifshotImagePreview.innerHTML = '';
                        // gifshotImagePreview.appendChild(animatedImage);

                        if (downloadAttrSupported) {
                            saveGIFButton.setAttribute('href', image);
                            saveGIFButton.classList.remove('hidden');
                        }
                    } else {
                        console.log('obj.error', obj.error);
                        console.log('obj.errorCode', obj.errorCode);
                        console.log('obj.errorMsg', obj.errorMsg);
                    }
                });
            }, false);

            saveGIFButton.addEventListener('click', function (e) {
                e.preventDefault();

                window.open(saveGIFButton.getAttribute('href'));

            }, false);

            document.addEventListener('change', function (e) {
                updateCodeBlock({
                    targetElem: e.target
                });
            });

            document.addEventListener('keyup', function (e) {
                updateCodeBlock({
                    targetElem: e.target
                });
            });
        };

        bindEvents();
        updateCodeBlock({
            targetElem: gifWidth
		
    });
}

function loopgifs(){
console(loopgifs);
for(i=3; i<newArray.length; i++){   
        // console.log(imgArray)
        console.log(newArray[i])
		alert(newArray[i]);
}		
	
}
    //function to display gifs
    function displayergif(){
        console.log("displayergif")
        if (allimage.length != 0) {
			alert("lkdsmlk");
            var animated;
            var myList;
		
            myList = document.createElement("ul"); 
            myList.classList.add("list-unstyled")                
            allimage.forEach(item => {                         
                let j = 0;
          
                var list = document.createElement("li");        
                animated = document.createElement('img')   
                animated.classList.add("allimage","col-md-6")     
                list.appendChild(animated)        
                animated.src = allimage[j]; 
                myList.appendChild(list)       
                j++;        
            });
			var finalpreview = animated.src;
			var zip = new JSZip();
			zip.file("Hello.txt", "Hello World\n");
			var img = zip.folder("images");
			img.file("smile.gif", finalpreview);
			zip.generateAsync({type:"base64"})
			.then(function (content) {
				location.href="data:application/zip;base64,"+content;
			});
        }else{
            
        }
    }
	


    // function to chunck array 
    function chunkArray(imgArray, chunk_size){
        console.log("chunkArray")
        var index = 0;
        var arrayLength = imgArray.length;

        for (index = 0; index < arrayLength; index += chunk_size) {
            myChunk = imgArray.slice(index, index+chunk_size);
            // Do something if you want with the group
            arrayChunked.push(myChunk);
        }
        return arrayChunked;
    }
    
}(window, document));
