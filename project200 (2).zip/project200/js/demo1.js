function toggle(){
  var gifSelector  = document.getElementById('gifaccordion');
        var mp4accordion = document.getElementById('mp4accordion');
        var gifmaker = document.getElementById("gifmaker");
        var mp4maker = document.getElementById("drag");
        mp4accordion.addEventListener("click",()=>{
          mp4maker.classList.toggle("hidden");
          gifmaker.classList.add("hidden");
        });
        gifSelector.addEventListener("click",()=>{
          gifmaker.classList.toggle("hidden");
          mp4maker.classList.add("hidden");
        });
};

var imgArray = []
function watermarkit(upload){
    console.log("watermarkit")
    var logo = document.getElementById("imgWaterMark").value;
    var imgExt = logo.substr(logo.lastIndexOf(".")+1);
    
    if (imgExt !== "png") {
        document.getElementById('status').innerHTML = "Please choose a png watermark"
    }else{
        
        var nlogo = logo.substr(12)
        var pos = document.getElementById("waterpos").value;
        var opacity  = document.getElementById("opacity").value;
        watermark([upload, nlogo])
            if (pos === "center") {
                watermark([upload, nlogo])
            .image(watermark.image.center(opacity))
            .then((img)=>{imgArray.push(img.src);});
            }else if (pos === "upperRight"){
                watermark([upload, nlogo])
            .image(watermark.image.upperRight(opacity))
            .then((img)=>{imgArray.push(img.src);});
            }else if (pos === "upperLeft"){
                watermark([upload, nlogo])
            .image(watermark.image.upperLeft(opacity))
            .then((img)=>{imgArray.push(img.src);});
            }else if (pos === "lowerRight"){
                watermark([upload, nlogo])
            .image(watermark.image.lowerRight(opacity))
            .then((img)=>{imgArray.push(img.src);});
            }else if (pos === "lowerLeft"){
            watermark([upload, nlogo])
            .image(watermark.image.lowerLeft(opacity))
            .then((img)=>{imgArray.push(img.src);});
            }
            // .image(watermark.image.lowerLeft(opacity))
            // // .then(img => document.getElementById('lower-right').appendChild(img));
            // .then((img)=>{imgArray.push(img.src);});
    }
}

(function(window, document) {
    var createGIFButton = document.querySelector('#create-gif');
    var imgHolder = document.querySelector('#imgHolder');
    var imgArray1= [];
    var imgArray2= [];
    var imgArray3= [];
    var imgArray4= [];
    var imgArray5= [];
    //if we have images loaded
    // imgHolder.addEventListener("change",detector())
    // var waterHolder  = document.getElementById('imgWaterMark')
    // waterHolder.addEventListener("change",detector());
    
    var allimage = []
    imgHolder.addEventListener("change",()=>{
        var images = imgHolder.files;
    var statusHolder = document.getElementById('status');
    var waterHolder  = document.getElementById('imgWaterMark').value;
    var nlogo = waterHolder.substr(12)
    if(images.length%3 !== 0 ){            
         statusHolder.innerHTML = "Please choose images in pair of 3.";
    }else{             
      if(images.length>0){
          //loop through them and process
          countimg = images.length/3;
          for(i=0; i<images.length; i++) {
              var file = images[i];
              if(file.type.match(/image.*/)){
                  imgsrc = URL.createObjectURL(images[i]);

                  if (waterHolder != "") {
                      watermarkit(imgsrc)                        
                  }else{
                      imgArray.push(imgsrc);
                  }
                  
                  createGIFButton.addEventListener('click',()=>{statusHolder.innerHTML = "";}); 
              }else{
                  document.getElementById('status').innerHTML = "This file does not seem to be a image.";
              }
          } 
          // var usedlnth = imgArray.length;
          // var separator = 0;
          // while(separator <= usedlnth){                               
              imgArray1 = imgArray.slice(0,3);
              imgArray2 = imgArray.slice(3,6);
              imgArray3 = imgArray.slice(6,9);
              imgArray4 = imgArray.slice(9,12);
              imgArray5 = imgArray.slice(12,15);
              
              console.log(JSON.stringify(imgArray))
              var mynewarray = [imgArray1, imgArray2, imgArray3, imgArray4, imgArray5];
              for (let i = 0; i < mynewarray.length; i++) {
                  if (mynewarray[i] != "") {
                      gifmaker(mynewarray[i]);
                  }else{
                      console.log("it is empty")
                  }
                  
              }              
              
      }else {
          document.getElementById('status').innerHTML = "Please select some images.";
      }  
    } 
    })

    function gifmaker(newArray){
        console.log("gifmaker")
        var saveGIFButton = document.querySelector('#save-gif');
        var downloadAttrSupported = ('download' in document.createElement('a'));
        var createGIFButton = document.querySelector('#create-gif');
        var gifSource = document.querySelector('#GIFSource');
        // var gifType = document.querySelector('#GIFType');
        var gifType = "animated";
        var filter = document.querySelector("#filter");
        var interval = document.querySelector("#interval");
        var numFrames = document.querySelector("#numFrames");
        var frameDuration = document.querySelector("#frameDuration");
        var gifHeight = document.querySelector("#gifHeight");
        var gifWidth = document.querySelector("#gifWidth");
        var progressBar = document.querySelector("progress");
        var imgWaterMark =document.querySelector("#imgWaterMark");
        var sampleInterval = document.querySelector('#sampleInterval');
        var numWorkers = document.querySelector('#numWorkers');
        var gifshotImagePreview = document.querySelector('.gifshot-image-preview-section');
        var placeholderDiv = document.querySelector('.placeholder-div');
        var placeholderDivDimensions = document.querySelector('.placeholder-div-dimensions');
        //process watermark image input 
        imgWaterMark.addEventListener("change",()=>{
            var statusHolder = document.getElementById('status');
            var myImg = imgWaterMark.value;
            var myimgdisplayer = document.createElement('img');
            var newImg = myImg.replace(/^C:\\fakepath\\/, "");
            var imgExtension = newImg.substr(newImg.lastIndexOf(".")+1);
            if (imgExtension != "png") {
                statusHolder.innerHTML = "Please choose png watermark";
            }else{
                myimgdisplayer.src = newImg;
                statusHolder.appendChild(myimgdisplayer);
            }
        });  
        
        //get selected options
        var getSelectedOptions = function () {
            console.log("getSelectedOptions")
            return {            
                gifWidth: Number(gifWidth.value),
                gifHeight: Number(gifHeight.value),
                images: gifSource.value === 'images' ? newArray : false,
                filter: filter.value,
                interval: Number(interval.value),
                numFrames: Number(numFrames.value),
                frameDuration: Number(frameDuration.value),
                imgWaterMark: imgWaterMark.value,
                text: "",
                fontWeight: "",
                fontSize: "",
                fontFamily: "",
                fontColor: "",
                textAlign: "",
                textBaseline: "",
                sampleInterval: Number(sampleInterval.value),
                numWorkers: Number(numWorkers.value)
            }
        };
        var passedOptions;
        var updateCodeBlock = function (obj) {
            console.log("updateCodeBlock")
        obj = obj || {};

        var targetElem = obj.targetElem;
        var selectedOptions = getSelectedOptions();
        var options = (function() {
            console.log("options")
            var obj = {};
            _.each(selectedOptions, function(val, key) {
                if (val) {
                    obj[key] = val;
                }
            });

            return obj;
        }());

        if (targetElem && (targetElem.id === 'gifWidth' || targetElem.id === 'gifHeight')) {
            if (selectedOptions.gifHeight && selectedOptions.gifWidth) {
                gifshotImagePreview.innerHTML = '';
                placeholderDiv.style.height = selectedOptions.gifHeight + 'px';
                placeholderDiv.style.width = selectedOptions.gifWidth + 'px';
                placeholderDivDimensions.innerHTML = selectedOptions.gifWidth + ' x ' + selectedOptions.gifHeight;

                if (selectedOptions.gifWidth < 60 || selectedOptions.gifHeight < 20) {
                    placeholderDivDimensions.classList.add('hidden');
                } else {
                    placeholderDivDimensions.classList.remove('hidden');
                }

                placeholderDiv.classList.remove('hidden');
            } else {
                placeholderDiv.classList.add('hidden');
            }
        }
        };
        var bindEvents = function () {
            console.log("bindEvents")
            createGIFButton.addEventListener('click', function (e) {
                e.preventDefault();

                passedOptions = _.merge(_.clone(getSelectedOptions()), {
                    progressCallback: function (captureProgress) {
                        gifshotImagePreview.innerHTML = '';
                        placeholderDiv.classList.add('hidden');
                        progressBar.classList.remove('hidden');
                        progressBar.value = captureProgress;
                    }
                });

                var method = gifType.value === 'snapshot' ? 'takeSnapShot' : 'createGIF';

                gifshot[method](passedOptions, function(obj) {
                    console.log(gifshot)
                    if (!obj.error) {
                        var image = obj.image;                        
                        allimage.push(image)
                        if(allimage.length != countimg){
                        }else{
                            displayergif()
                        }
                        progressBar.classList.add('hidden');
                        progressBar.value = 0;

                        placeholderDiv.classList.add('hidden');

                        if (downloadAttrSupported) {
                            saveGIFButton.setAttribute('href', image);
                            saveGIFButton.classList.remove('hidden');
                        }
                    } else {
                        console.log('obj.error', obj.error);
                        console.log('obj.errorCode', obj.errorCode);
                        console.log('obj.errorMsg', obj.errorMsg);
                    }
                });
                
            }, false);
            
            saveGIFButton.addEventListener('click', function (e) {
            saveGIFButton.getAttribute('href');
            }, false);
        };
        bindEvents();
        updateCodeBlock({
            targetElem: gifWidth
        });
    }
    
        function displayergif(){
            console.log("displayergif")
            if (allimage.length != 0) {
                var gifshotImagePreview = document.querySelector('.gifshot-image-preview-section');
                var animated;
                var myList;      
                myList = document.createElement("ul"); 
                myList.classList.add("list-unstyled")                
                allimage.forEach(item => {                         
                    let j = 0;
                            
                    var list = document.createElement("li");        
                    animated = document.createElement('img')   
                    animated.classList.add("allimage","col-md-6")     
                    list.appendChild(animated)        
                    animated.src = allimage[j]; 
                    myList.appendChild(list)       
                    j++;        
                });
                   
                gifshotImagePreview.innerHTML = '';
                gifshotImagePreview.appendChild(myList);
            }else{
                gifshotImagePreview.innerHTML = 'no image to display';
            }
        }
}(window, document));
