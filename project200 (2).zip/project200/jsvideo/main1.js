/* function to add a watermark start*/
function watermarkitvid(uploadvid){
    var logovid = document.getElementById("imgWaterMarkvid").value;
    var imgExtvid = logovid.substr(logovid.lastIndexOf(".")+1);
    
    if (imgExtvid !== "png") {
        document.getElementById('status').innerHTML = "Please choose a png watermark"
    }else{
        var nlogovid = logovid.substr(12)
        var posvid = document.getElementById("waterposvid").value;
        var opacityvid  = document.getElementById("opacityvid").value;
        watermark([uploadvid, nlogovid])
            if (posvid === "center") {
                watermark([uploadvid, nlogovid])
            .image(watermark.image.center(opacityvid))
            .then((img)=>{imgArrayvid.push(img.src);});
            }else if (posvid === "upperRight"){
                watermark([uploadvid, nlogovid])
            .image(watermark.image.upperRight(opacityvid))
            .then((img)=>{imgArrayvid.push(img.src);});
            }else if (posvid === "upperLeft"){
                watermark([uploadvid, nlogovid])
            .image(watermark.image.upperLeft(opacityvid))
            .then((img)=>{imgArrayvid.push(img.src);});
            }else if (posvid === "lowerRight"){
                watermark([uploadvid, nlogovid])
            .image(watermark.image.lowerRight(opacityvid))
            .then((img)=>{imgArrayvid.push(img.src);});
            }else if (posvid === "lowerLeft"){
                watermark([uploadvid, nlogovid])
            .image(watermark.image.lowerLeft(opacityvid))
            .then((img)=>{var fileimg = img.src; console.log(fileimg); });
            }
            // .image(watermark.image.lowerLeft(opacityvid))
            // // .then(img => document.getElementById('lower').appendChild(img));
            // .then((img)=>{imgArrayvid.push(img.src);});
    }
}
/* function to add a watermark ends*/

/* Drag'n drop stuff */
            var drag = document.getElementById("drag");
            var fbutton = document.getElementById("fbutton");
            var createvideo = document.getElementById("createvideo");
            var format   = document.getElementById("format");
            var files = document.getElementById("filesinput");

            var ctx = 0;

            var canvas = document.getElementById("canvas");
            var context = canvas.getContext("2d");

            //image to video via Whammy
            var video = new Whammy.Video(15);

            var filesarr = [];
            var tempArray = [];
            var allVideos = []
            createvideo.addEventListener("click", function() {
                document.getElementById('status').innerHTML = "Working... Please Wait.";
                // var awesome = document.getElementById('awesome');
                // awesome.classList.toggle('hidden');
                // awesome.src = "";
                ctx = 0;

                canvas.width = document.getElementById("width").value;
                canvas.height = document.getElementById("height").value;
                video = new Whammy.Video(document.getElementById("framerate").value);
                var statusHolder = document.getElementById('status');
                //if we have images loaded
                if(filesarr.length%3 !== 0 ){ 
                    statusHolder.innerHTML = "Please choose images in pair of 3.";
                }else{ 
                    if(tempArray.length>0){
                        for (let j = 0; j < tempArray.length; j++) {
                            const element = tempArray[j];
                            proccessor(element)
                            console.log(element)
                        }
                        //loop through them and process
                    } else {
                        document.getElementById('status').innerHTML = "Please select some images.";
                    }
                }
            }, false);
            function proccessor(usebleArray){
                for(i=0; i < usebleArray.length; i++) {
                    var file = usebleArray[i];
                    if(file.type.match(/image.*/)){
                        // watermarkitvid(file)
                        process(file)                                
                    } else {
                        document.getElementById('status').innerHTML = "This file does not seem to be a image.";
                    }
                }
            }
            fbutton.addEventListener("click", function() {
                document.getElementById('filesinput').click();
            }, false);

            drag.ondragover = function(e) {e.preventDefault()}
            drag.ondrop = function(e) {
                e.preventDefault();
                filesarr = e.dataTransfer.items;
                document.getElementById('status').innerHTML = "Please select options and click on Create Video.";
            }

            //process files VIA INPUT
            files.addEventListener("change", function (e) {
                filesarr = e.target.files;
                document.getElementById('status').innerHTML = "Please select options and click on Create Video.";
                // chunkArray(filesarr, 3);
                var newfileArray =[];
                for (let i = 0; i < filesarr.length; i++) {
                    const element = filesarr[i]; 
                    newfileArray.push(element)                   
                }

                chunkArray(newfileArray, 3)
            }, false);
            
            function chunkArray(filesarr, chunk_size){
                
                var index = 0;
                var arrayLength = filesarr.length;
                
                
                for (index = 0; index < arrayLength; index += chunk_size) {
                    myChunk = filesarr.slice(index, index+chunk_size);
                    // Do something if you want with the group
                    tempArray.push(myChunk);
                }
            
                return tempArray;
            }
            
            /* main process function */
            function process(file) {

                var reader = new FileReader();
                reader.onload = function(event) {
                    var dataUri = event.target.result;
                    var img = new Image();
                 
                    //load image and drop into canvas
                    img.onload = function() {
                        //a custom fade in and out slideshow
                        context.globalAlpha = 0.2;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);
                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 0.4;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);
                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 0.6;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);
                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 0.8;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);                       
                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 1;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);

                        //this should be a loop based on some user input
                        video.add(context);
                        video.add(context);
                        video.add(context);
                        video.add(context);
                        video.add(context);
                        video.add(context);
                        video.add(context);

                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 0.8;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);
                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 0.6;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);
                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 0.4;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);
                              
                        ctx++;
                        finalizeVideo();
                    };
                    img.src = dataUri;
                };

                reader.onerror = function(event) {
                    console.error("File could not be read! Code " + event.target.error.code);
                };

                reader.readAsDataURL(file);
            }      

function finalizeVideo(){
  //check if its ready
  if(ctx==tempArray.length){

    var start_time = +new Date;
    
    var output = video.compile();
     var end_time = +new Date;
     var url = webkitURL.createObjectURL(output);
     allVideos.push(url);
     console.log(allVideos)
    document.getElementById('downloadmp4').style.display = '';
    document.getElementById('downloadmp4').href = url;
    var progressBar = document.getElementsByClassName('progressBar')[0];
    var progressBarCounter = document.getElementById("counterup");
    var gifcanva = document.getElementsByClassName("placeholder-div")[0];
    var counterup = 1;
    var addperc = "";
    var difference = end_time - start_time;
    var forInterval = difference/3;
    progressBar.classList.remove("hidden");
    var myfunc = setInterval(() => {
        addperc = addperc + 25;
        addperc = parseFloat(addperc);
        var classname = "progressBar"
        if(progressBar.classList.contains("progressBar100")){
            clearInterval(myfunc);
        }else{
            progressBar.classList.add("progressBar"+ addperc);
            progressBarCounter.innerHTML = counterup;
            counterup++;
        }
    }, forInterval);
    
    gifcanva.classList.add("hidden");
    // document.getElementById('awesome').src = "video.mp4"; //toString converts it to a URL via Object URLs, falling back to DataURL
    
    document.getElementById('status').innerHTML = "Compiled Video in " + (end_time - start_time) + "ms, file size: " + Math.ceil(output.size / 1024) + "KB";

  }

}

