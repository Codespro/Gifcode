/* add a watermark  starts */

function watermarkitvid(uploadvid){
        var logovid = document.getElementById("imgWaterMarkvid").value;
        var nlogovid = logovid.substr(12)
        var posvid = document.getElementById("waterposvid").value;
        var opacityvid  = document.getElementById("opacityvid").value;
        
            watermark([uploadvid, nlogovid])
            if (posvid === "center") {
                watermark([uploadvid, nlogovid])
            .image(watermark.image.center(opacityvid))
            .then((img)=>{pushTofilesarr(img)});
            }else if (posvid === "upperRight"){
                watermark([uploadvid, nlogovid])
            .image(watermark.image.upperRight(opacityvid))
            .then((img)=>{pushTofilesarr(img)});
            }else if (posvid === "upperLeft"){
                watermark([uploadvid, nlogovid])
            .image(watermark.image.upperLeft(opacityvid))
            .then((img)=>{pushTofilesarr(img)});
            }else if (posvid === "lowerRight"){
                watermark([uploadvid, nlogovid])
            .image(watermark.image.lowerRight(opacityvid))
            .then((img)=>{pushTofilesarr(img)});
            }else if (posvid === "lowerLeft"){
                watermark([uploadvid, nlogovid])
            .image(watermark.image.lowerLeft(opacityvid))
            .then((img)=>{pushTofilesarr(img) });
            }
        
}


/* display function and store to filesarr starts */
function pushTofilesarr(img){
    var imgsrc = img.src;
    var blob = dataURLtoBlob(imgsrc)
    arrayToBeChunked.push(blob)
    
}
/* display function and store to filesarr ends */
/* function to turn data url to blob starts */

function dataURLtoBlob(dataurl) {
    var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while(n--){
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], {type:mime});
    
}

/* functin to turn data url to blob ends */

/* function to chunck filesarr into 3 small arrays starts */

function chunkArray(arrayToBeChunked, chunk_size){
    var index = 0;
    var arrayLength = arrayToBeChunked.length;
    // filesarr = arrayToBeChunked
    // processOneFilesarr(filesarr) 
    for (index = 0; index < arrayLength; index += chunk_size) {
        myChunk = arrayToBeChunked.slice(index, index+chunk_size);
        // Do something if you want with the group
        arrayChunked.push(myChunk);
    }
    var newArrayLength = arrayChunked.length
    for (let k = 0; k < newArrayLength; k++) {
        filesarr = arrayChunked[k];
        processOneFilesarr(filesarr)
        
    }
    // return filesarr;
    
}

/* function to chunck filesarr into 3 small arrays ends */


/* add a watermark  ends */


        /* Drag'n drop stuff */
            var drag = document.getElementById("dragfile");
            var fbutton = document.getElementById("fbutton");
            var createvideo = document.getElementById("createvideo");
            var files = document.getElementById("filesinput");
            

            //other variables
            var filesarr = []
            var arrayToBeChunked = []
            var arrayChunked = []
            var fileArray= []
            var toWaterMark = []
            var imgWaterMarkvid = document.getElementById("imgWaterMarkvid");
            var opacityvid = document.getElementById("opacityvid");
            var positionvid = document.getElementById("waterposvid");
            var allvideos = []


            fbutton.addEventListener("click", function() {
                document.getElementById('filesinput').click();
            }, false);

            drag.ondragover = function(e) {e.preventDefault()}
            drag.ondrop = function(e) {
                e.preventDefault();
                fileArray = e.dataTransfer.items;
                document.getElementById('status').innerHTML = "Please select options and click on Create Video.";
            }

            //process files VIA INPUT
            files.addEventListener("change", function (e) {
                fileArray = e.target.files;
                if (fileArray.length%3 != 0) {
                    document.getElementById('status').innerHTML = "Please select images in pair of 3";
                }else{
                    for (let i = 0; i < fileArray.length; i++) {
                        let file = fileArray[i];
                        if(file.type.match(/image.*/)){
                            file = URL.createObjectURL(file);
                            toWaterMark.push(file); 
                        }else{
                            document.getElementById('status').innerHTML = "This file does not seem to be a image.";
                        }
                    }
                    document.getElementById('status').innerHTML = "Please select options and click on Create Video.";
                }
                    
            }, false);
            
            // Add a watermark to every picture and overwrite filesarr 
            imgWaterMarkvid.addEventListener("change",()=>{
                filesarr = [] 
                var logovid = document.getElementById("imgWaterMarkvid").value;
                var imgExtvid = logovid.substr(logovid.lastIndexOf(".")+1);
                //check if filesarr is not empty
                if (toWaterMark.length > 0) {
                    if (imgExtvid !== "png") {
                        document.getElementById('status').innerHTML = "Please choose a png watermark"
                    }else{
                        document.getElementById('status').innerHTML = "Good to go"
                        for (let i = 0; i < toWaterMark.length; i++) {
                            let uploaded = toWaterMark[i];
                            watermarkitvid(uploaded)
                        }                        
                    }
                }else{
                    document.getElementById('status').innerHTML = "Please choose image first"
                }            
            });

            // check if position is changed and add update the watermark
            
            positionvid.addEventListener("change",()=>{
                filesarr = []
                var logovid = document.getElementById("imgWaterMarkvid").value;
                var imgExtvid = logovid.substr(logovid.lastIndexOf(".")+1);
                //check if filesarr is not empty
                if (toWaterMark.length > 0) {
                    if (imgExtvid !== "png") {
                        document.getElementById('status').innerHTML = "Please choose a png watermark"
                    }else{
                        document.getElementById('status').innerHTML = "Good to go"
                        for (let i = 0; i < toWaterMark.length; i++) {
                            let uploaded = toWaterMark[i];
                            watermarkitvid(uploaded)
                        }                        
                    }
                }else{
                    document.getElementById('status').innerHTML = "Please choose image first"
                }            
            });
            
            // check if opacity is changed and add update the watermark
            
            opacityvid.addEventListener("change",()=>{
                filesarr = []
                
                var logovid = document.getElementById("imgWaterMarkvid").value;
                var imgExtvid = logovid.substr(logovid.lastIndexOf(".")+1);
                //check if filesarr is not empty
                if (toWaterMark.length > 0) {
                    if (imgExtvid !== "png") {
                        document.getElementById('status').innerHTML = "Please choose a png watermark"
                    }else{
                        document.getElementById('status').innerHTML = "Good to go"
                        for (let i = 0; i < toWaterMark.length; i++) {
                            let uploaded = toWaterMark[i];
                            watermarkitvid(uploaded)
                        }                        
                    }
                }else{
                    document.getElementById('status').innerHTML = "Please choose image first"
                }            
            });


            var ctx = 0;

            

            //image to video via Whammy
            var video = new Whammy.Video(15);

               
/* function to process one  filesarr starts*/

function processOneFilesarr(filesarr){
    document.getElementById('status').innerHTML = "Working... Please Wait.";

    document.getElementById('awesome').src = "";
    ctx = 0;
    var canvas = document.getElementById("canvas").cloneNode();
    var context = canvas.getContext("2d");
    canvas.width = document.getElementById("width").value;
    canvas.height = document.getElementById("height").value;
    var video = new Whammy.Video(document.getElementById("framerate").value);

    //if we have images loaded
    if(filesarr.length>0){

        //loop through them and process
        for(i=0; i<filesarr.length; i++) {
            var file = filesarr[i];
            // if(file.type.match(/image.*/)){
                process(file, canvas, context);
            // } else {
            //     document.getElementById('status').innerHTML = "This file does not seem to be a image.";
            // }
        }

    } else {
        document.getElementById('status').innerHTML = "Please select some images.";
    }
    
}

/* funciton to process one filesarr ends */

            createvideo.addEventListener("click", function() {
                chunkArray(arrayToBeChunked,3)
            }, false);

            /* main process function */
            function process(file, canvas, context) {
                
                var reader = new FileReader();
                reader.onload = function(event) {
                    var dataUri = event.target.result;
                    var img = new Image();
                 
                    //load image and drop into canvas
                    img.onload = function() {

                        //a custom fade in and out slideshow
                        context.globalAlpha = 0.2;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);
                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 0.4;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);
                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 0.6;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);
                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 0.8;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);                       
                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 1;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);

                        //this should be a loop based on some user input
                        video.add(context);
                        video.add(context);
                        video.add(context);
                        video.add(context);
                        video.add(context);
                        video.add(context);
                        video.add(context);

                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 0.8;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);
                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 0.6;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);
                        context.clearRect(0,0,context.canvas.width,context.canvas.height);
                        context.globalAlpha = 0.4;
                        context.drawImage(img, 0, 0, canvas.width, canvas.height);
                        video.add(context);
                              
                        ctx++;
                        // finalizeVideo();
                        if(ctx%3 == 0){
                            var start_time = +new Date;
                            var url =webkitURL.createObjectURL(video.compile())
                            var end_time = +new Date;
                            allvideos.push(url)
                            document.getElementById('status').innerHTML = "Compiled Video in " + (end_time - start_time) + "ms, file size: " + Math.ceil(url.size / 1024) + "KB";
                        }     
                        if(ctx == arrayToBeChunked.length){
                            displayvideo("")
                        }                
                    };
                    img.src = dataUri;
                };

                reader.onerror = function(event) {
                    console.error("File could not be read! Code " + event.target.error.code);
                };
                reader.readAsDataURL(file);
                
            }      
// function to display video

function displayvideo(url){
      var containervid = document.getElementsByClassName("gifshot-image-preview-section")[0]
      var ulement = document.createElement("ul")
      ulement.classList.add("list-unstyled")   
      allvideos.forEach(element => {
          let j = 0;
         var lielement = document.createElement("li")
         lielement.classList.add("col-md-6","allvideo")
         var videlement = document.createElement("a")
         videlement.classList.add("allvideoa")
         videlement.href = allvideos[j]
         lielement.appendChild(videlement)
         ulement.appendChild(lielement);
         j++
      });
      containervid.appendChild(ulement)
      document.getElementById('awesome').src = url; //toString converts it to a URL via Object URLs, falling back to DataURL
      document.getElementById('downloadmp4').style.display = '';
      document.getElementById('downloadmp4').href = url;

      var myclass = document.getElementsByClassName("allvideoa");
      for (let i = 0; i < myclass.length; i++) {
          const element = myclass[i];
          element.setAttribute("download","warda.mp4")
          element.innerHTML = "download mp4"
      }

}

function finalizeVideo(){
  //check if its ready
  if(ctx==filesarr.length){
      var start_time = +new Date;
      var output = video.compile();
      var end_time = +new Date;
      var url = webkitURL.createObjectURL(output);
      allvideos.push(url);

      document.getElementById('awesome').src = url; //toString converts it to a URL via Object URLs, falling back to DataURL
      document.getElementById('downloadmp4').style.display = '';
      document.getElementById('downloadmp4').href = url;
      document.getElementById('status').innerHTML = "Compiled Video in " + (end_time - start_time) + "ms, file size: " + Math.ceil(output.size / 1024) + "KB";
      displayvideo(url)
  }
  
}