<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Images to Video Converter</title>

<link rel="stylesheet" href="style.css">
<script src="jquery.min.js"></script>
</head>
<body>
<div id="wrapper"><div id="header"><h1 style="margin-left:200px;">Images to Video Converter</h1></div>
<div id="content">
<form action='index.php' method='POST' enctype="multipart/form-data">
    <input type='file' id='ex3' name='ex3[]' multiple='multiple' /><br /><br /><br />
    <input style="margin-left:300px;" type='submit' value='Convert' /> 
</form>
<script src="preview.js">
</script>

<script>$(document).ready(function() {

  
	  $('#ex3').simpleFilePreview({
		    existingFiles: {
		      "001": "uploads/img001.jpg",
		      "002": "uploads/img002.jpg",
		      "003": "uploads/img003.jpg",
		      "004": "uploads/img004.jpg",
		      "005": "uploads/img005.jpg",
		      "006": "uploads/img006.jpg",
		      "007": "uploads/img007.jpg",
		      "008": "uploads/img008.jpg",
		      "009": "uploads/img009.jpg",
		      "010": "uploads/img010.jpg",
		      "011": "uploads/img011.jpg",
		      "012": "uploads/img012.jpg",
		      "013": "uploads/img013.jpg",
		      "014": "uploads/img014.jpg",
		      "015": "uploads/img015.jpg",
		      "016": "uploads/img016.jpg"
		    }
		  });


  
});</script>
</div></div>
</body></html>